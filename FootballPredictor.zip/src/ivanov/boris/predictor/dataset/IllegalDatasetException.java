package ivanov.boris.predictor.dataset;

public class IllegalDatasetException extends RuntimeException {

}
